from multipart import parse_form_data
from src.db.database import insert

from src.templates import render_template
from src.models.shopping_cart import Product


def home(environ: dict) -> str:
    return render_template("src/views/index.html")


def form(environ: dict) -> str:
    method: str = environ.get("REQUEST_METHOD", "").upper()

    context: dict[str, str | float] = {
        "name": "",
        "error_name": "",
        "price": "",
        "price_error": "",
        "description": ""
    }

    if method == "GET":
        return render_template("src/views/form.html", context)

    if method == "POST":
        form, _ = parse_form_data(environ)

        if "name" in form:
            name: str = form["name"].strip()

            if not name:
                context["error_name"] = "El nombre es obligatorio."

            if name.find(" ") != -1:
                context["error_name"] = "No se pueden poner espacios."
                context["name"] = name

        if "price" in form:
            if not form["price"]:
                context["price_error"] = "Hay que poner precio."

            if form["price"].replace(",", ".").replace(".","").isnumeric():
                price: float = float(form["price"].replace(",","."))
                context["price"] = price
            else:
                context["price_error"] = f"{form['price']} no es un número."

    context["description"] = form["description"]

    if not context["error_name"] and not context["price_error"]:
        product: Product = Product(name, form["description"], price)
        insert(product)
        return render_template("src/views/index.html", context)

    return render_template("src/views/form.html", context)


def error404() -> str:
    return render_template("src/views/404.html")
