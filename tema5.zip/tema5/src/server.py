from typing import Callable, Iterator

from src.controllers import home, form, error404
from src.models.shopping_cart import Product, ShoppingCart


def app(environ: dict, start_response: Callable) -> Iterator:
    path: str = environ.get("PATH_INFO")
    headers: list[tuple[str, str]] = [
        ("Content-Type", "text/html")
    ]

    if path.endswith("/"):
        path = path[:-1]

    if path == "" or "/":
        data: str = form(environ)
    elif path == "/product/db/add":
        data: str = form(environ)
    else:
        data: str = error404()

    data_in_bytes: bytes = data.encode("utf-8")
    headers.append(("Content-Length", str(len(data_in_bytes))))
    start_response("200 OK", headers)

    return iter([data_in_bytes])
