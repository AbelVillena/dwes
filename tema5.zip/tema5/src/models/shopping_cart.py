from uuid import uuid4


class Product:
    def __init__(self, name: str, description: str, price: float):
        self.__uuid: str = str(uuid4())
        self.__name = name
        self.__description = description
        self.__price = price

    @property
    def uuid(self) -> str:
        return self.__uuid

    @property
    def name(self) -> str:
        return self.__name

    @property
    def description(self) -> str:
        return self.__description

    @property
    def price(self) -> float:
        return self.__price

    def __str__(self) -> str:
        return f"{self.__name} - {self.__description} - {self.__price:.2f}€"

    def __repr__(self) -> str:
        return f"Product(uuid={self.__uuid}, name={self.__name}, description={self.__description}, price={self.__price})"


class ShoppingCart:
    def __init__(self):
        self.__products: list[Product] = []

    @property
    def products(self) -> str:
        return self.__products

    def total_price(self) -> float:
        return sum([p.price for p in self.__products])

    def add_product(self, p: Product):
        self.__products.append(p)

    def remove_product(self, p: Product):
        self.__products = [products for products in self.__products
                           if products.uuid != p.uuid]
